package com.example.demo;

import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import jakarta.annotation.Resource;

@AutoConfigureTestDatabase(replace = Replace.NONE)
@SpringBootTest
public class DatabaseTest {

    @Resource
    private LockRespository repository;

    @Test
    void testLockSaving() {
        
    }
    
}
